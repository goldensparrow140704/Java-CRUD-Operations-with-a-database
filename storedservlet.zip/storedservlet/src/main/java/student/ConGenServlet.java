package student;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ConGenServlet")
public class ConGenServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        ArrayList<String> countryCodes = new ArrayList<>();
        ArrayList<String> countryNames = new ArrayList<>();
        ArrayList<String> genderValues = new ArrayList<>();
        ArrayList<String> interestlst = new ArrayList<>();

        final String DB_URL = "jdbc:sqlserver://localhost\\SQLEXPRESS;Database=students;integratedSecurity=true;Trusted_Connection=True;encrypt=true;trustServerCertificate=true";
        final String JDBC_DRIVER = "com.microsoft.sqlserver.jdbc.SQLServerDriver";

        try {
            Class.forName(JDBC_DRIVER);
            Connection conn = DriverManager.getConnection(DB_URL);
            Statement stmt = conn.createStatement();

          
            ResultSet rsCountries = stmt.executeQuery("getCountryRecords");
            while (rsCountries.next()) {
                countryNames.add(rsCountries.getString("country_name"));
                countryCodes.add(rsCountries.getString("country_code"));
            }
            rsCountries.close();

            ResultSet rsGenders = stmt.executeQuery("getGenderOptions");
            while (rsGenders.next()) {
                genderValues.add(rsGenders.getString("options"));
            }
            rsGenders.close();
            
            
            ResultSet rs=stmt.executeQuery("showAreaOfInterest");
            while (rs.next()) {
                interestlst.add(rs.getString("area_of_interest"));
            }
            rs.close();
            
            request.setAttribute("countryCodes", countryCodes);
            request.setAttribute("countryNames", countryNames);
            request.setAttribute("genderValues", genderValues);
            request.setAttribute("interestlst", interestlst);

            
            request.getRequestDispatcher("studentform/index.jsp").forward(request, response);

            stmt.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
