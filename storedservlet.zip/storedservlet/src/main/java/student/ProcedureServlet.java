package student;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/ProcedureServlet")
public class ProcedureServlet extends HttpServlet {

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        if (action == null) action = "list";

        switch (action) {
            case "create":
                request.getRequestDispatcher("procedure/CreateProcedure.jsp").forward(request, response);
                break;
            case "edit":
            	String procedureName = request.getParameter("name");
                request.setAttribute("procedureName", procedureName);
                request.getRequestDispatcher("procedure/editProcedure.jsp").forward(request, response);
                break;
            case "delete":
                deleteProcedure(request.getParameter("name"));
                response.sendRedirect("ProcedureServlet");
                break;
            case "show":
                String showName = request.getParameter("name");
                String procedureText = getProcedureText(showName);
                request.setAttribute("procedureText", procedureText);
                request.getRequestDispatcher("procedure/showProcedure.jsp").forward(request, response);
                break;
            default:
                List<String> procedures = listProcedures();
                request.setAttribute("procedures", procedures);
                request.getRequestDispatcher("procedure/listProcedures.jsp").forward(request, response);
                break;
        }
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        String name = request.getParameter("procedureName");
        String sql = request.getParameter("procedureSQL");

        switch (action) {
            case "create":
                createProcedure(name, sql);
                break;
            case "edit":
                updateProcedure(name, sql);
                break;
        }
        response.sendRedirect("ProcedureServlet");
    }

    public List<String> listProcedures() {
        List<String> procedures = new ArrayList<>();
        try (Connection conn = getConnection(); 
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT name FROM sys.objects WHERE type_desc = 'SQL_STORED_PROCEDURE';"))
     
        		{
            while (rs.next()) {
                procedures.add(rs.getString("name"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        System.out.print(procedures);
        return procedures;
        
    }
   

    private void createProcedure(String name, String sql) {
        try (Connection conn = getConnection(); 
             Statement stmt = conn.createStatement()) {
             stmt.execute(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void updateProcedure(String name, String sql) {
    	 try (Connection conn = getConnection();
                 Statement stmt = conn.createStatement()) {
                stmt.execute(sql); 
            } catch (SQLException e) {
                e.printStackTrace();
            }
    }

    private void deleteProcedure(String name) {
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement()) {
            stmt.execute("DROP PROCEDURE IF EXISTS " + name);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    private String getProcedureText(String procedureName) {
        String procedureText = "";
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("sp_helptext '" + procedureName + "'")) {
            while (rs.next()) {
                procedureText += rs.getString(1); 
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return procedureText;
    }

    public Connection getConnection() throws SQLException {
    	  final String DB_URL = "jdbc:sqlserver://localhost\\SQLEXPRESS;Database=students;integratedSecurity=true;Trusted_Connection=True;encrypt=true;trustServerCertificate=true";
          final String JDBC_DRIVER = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
    	try {
    	Class.forName(JDBC_DRIVER);
    	} catch (ClassNotFoundException e) {
    	e.printStackTrace();
    	}
    	return DriverManager.getConnection(DB_URL);
    	
    }
}

