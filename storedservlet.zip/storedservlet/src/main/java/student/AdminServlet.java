package student;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.ResultSetMetaData;

@WebServlet("/AdminServlet")
public class AdminServlet extends HttpServlet {
    private static final String DB_URL = "jdbc:sqlserver://localhost\\SQLEXPRESS;Database=students;integratedSecurity=true;Trusted_Connection=True;encrypt=true;trustServerCertificate=true";
    private static final String JDBC_DRIVER = "com.microsoft.sqlserver.jdbc.SQLServerDriver";

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        try {
            Class.forName(JDBC_DRIVER);
            try (Connection conn = DriverManager.getConnection(DB_URL)) {
                if ("listTables".equals(action)) {
                    listTables(conn, request, response);
                } else if ("viewRecords".equals(action)) {
                    viewRecords(conn, request, response);
                } else if ("deleteRecord".equals(action)) {
                    deleteRecord(conn, request, response);
                } else if ("editRecord".equals(action)) {
                    editRecord(conn, request, response);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "An error occurred: " + e.getMessage());
            request.getRequestDispatcher("listTables.jsp").forward(request, response);
        }
    }

    private void listTables(Connection conn, HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
        List<String> tables = new ArrayList<>();
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT table_name FROM information_schema.tables WHERE table_type = 'BASE TABLE'")) {
            while (rs.next()) {
                tables.add(rs.getString("table_name"));
            }
        }
        request.setAttribute("tables", tables);
        request.getRequestDispatcher("listTables.jsp").forward(request, response);
    }

    private void viewRecords(Connection conn, HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
        String tableName = request.getParameter("tableName");
        List<String> columns = new ArrayList<>();
        List<List<Object>> records = new ArrayList<>();

        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM " + tableName)) {
            ResultSetMetaData meta = rs.getMetaData();
            for (int i = 1; i <= meta.getColumnCount(); i++) {
                columns.add(meta.getColumnName(i));
            }

            while (rs.next()) {
                List<Object> record = new ArrayList<>();
                for (int i = 1; i <= meta.getColumnCount(); i++) {
                    record.add(rs.getObject(i));
                }
                records.add(record);
            }
        }
        request.setAttribute("currentTable", tableName);
        request.setAttribute("columns", columns);
        request.setAttribute("records", records);
        request.getRequestDispatcher("listTables.jsp").forward(request, response);
    }

    private void deleteRecord(Connection conn, HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
        String tableName = request.getParameter("tableName");
        String columnName=request.getParameter("columnName");
        String recordId = request.getParameter("recordId");

        if (recordId == null || recordId.trim().isEmpty() || tableName == null || tableName.trim().isEmpty()) {
            response.sendRedirect("AdminServlet?action=viewRecords&tableName=" + tableName + "&error=Invalid parameters for deletion.");
            return;
        }

        try (Statement stmt = conn.createStatement()) {
            String query = "DELETE FROM [" + tableName + "] WHERE ["+columnName+"] ="+recordId;
            stmt.executeUpdate(query);
        }

        response.sendRedirect("AdminServlet?action=viewRecords&tableName=" + tableName);
    }

    private void editRecord(Connection conn, HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
        String tableName = request.getParameter("tableName");
        String columnName = request.getParameter("columnName");
        String value = request.getParameter("value");
        String condition = request.getParameter("condition");

        if (tableName == null || columnName == null || value == null || condition == null ||
            tableName.trim().isEmpty() || columnName.trim().isEmpty() || condition.trim().isEmpty()) {
            response.sendRedirect("AdminServlet?action=viewRecords&tableName=" + tableName + "&error=Invalid parameters for editing.");
            return;
        }

        try (Statement stmt = conn.createStatement()) {
            String query = "UPDATE [" + tableName + "] SET [" + columnName + "] = '" + value + "' WHERE " + condition;
            stmt.executeUpdate(query);
        }

        response.sendRedirect("AdminServlet?action=viewRecords&tableName=" + tableName);
    }
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        try (Connection connection = DriverManager.getConnection(DB_URL)) {
            if ("createTable".equals(action)) {
                createTable(request, response, connection);
            } else if ("insertRecord".equals(action)) {
                insertRecord(request, response, connection);
            } else if ("deleteTable".equals(action)) {
                deleteTable(request, response, connection);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.getWriter().println("Error: " + e.getMessage());
        }
    }

    private void listTables(HttpServletRequest request, HttpServletResponse response, Connection connection) throws SQLException, ServletException, IOException {
        List<String> tables = new ArrayList<>();
        Statement statement = connection.createStatement();
        ResultSet resultSet = statement.executeQuery("SHOW TABLES");
        while (resultSet.next()) {
            tables.add(resultSet.getString(1));
        }
        request.setAttribute("tables", tables);
        request.getRequestDispatcher("listTables.jsp").forward(request, response);
    }

    private void createTable(HttpServletRequest request, HttpServletResponse response, Connection connection) throws SQLException, IOException {
        String tableName = request.getParameter("tableName");
        String columns = request.getParameter("columns"); // Example: "id INT PRIMARY KEY, name VARCHAR(100)"
        String query = "CREATE TABLE " + tableName + " (" + columns + ")";
        try (Statement statement = connection.createStatement()) {
            statement.executeUpdate(query);
            response.getWriter().println("Table '" + tableName + "' created successfully!");
        }
    }

    private void deleteTable(HttpServletRequest request, HttpServletResponse response, Connection connection) throws SQLException, IOException {
        String tableName = request.getParameter("tableName");
        String query = "DROP TABLE " + tableName;
        try (Statement statement = connection.createStatement()) {
            statement.executeUpdate(query);
            response.getWriter().println("Table '" + tableName + "' deleted successfully!");
        }
    }

    private void viewRecords(HttpServletRequest request, HttpServletResponse response, Connection connection) throws SQLException, ServletException, IOException {
        String tableName = request.getParameter("tableName");
        List<String> columns = new ArrayList<>();
        List<List<Object>> records = new ArrayList<>();

        try (Statement statement = connection.createStatement()) {
            ResultSet resultSet = statement.executeQuery("SELECT * FROM " + tableName);
            ResultSetMetaData metaData = resultSet.getMetaData();
            int columnCount = metaData.getColumnCount();

            // Fetch column names
            for (int i = 1; i <= columnCount; i++) {
                columns.add(metaData.getColumnName(i));
            }

            // Fetch records
            while (resultSet.next()) {
                List<Object> record = new ArrayList<>();
                for (int i = 1; i <= columnCount; i++) {
                    record.add(resultSet.getObject(i));
                }
                records.add(record);
            }
        }

        request.setAttribute("currentTable", tableName);
        request.setAttribute("columns", columns);
        request.setAttribute("records", records);
        request.getRequestDispatcher("listTables.jsp").forward(request, response);
    }

    private void insertRecord(HttpServletRequest request, HttpServletResponse response, Connection connection) throws SQLException, IOException {
        String tableName = request.getParameter("tableName");
        String values = request.getParameter("values"); // Example: "1, 'John Doe', 25"
        String query = "INSERT INTO " + tableName + " VALUES (" + values + ")";
        try (Statement statement = connection.createStatement()) {
            statement.executeUpdate(query);
            response.getWriter().println("Record inserted successfully into table '" + tableName + "'!");
        }
    }

}
