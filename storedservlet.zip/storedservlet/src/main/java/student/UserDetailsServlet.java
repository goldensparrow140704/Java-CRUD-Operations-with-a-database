package student;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest; 
import javax.servlet.http.HttpServletResponse;

@WebServlet("/UserDetailsServlet")
public class UserDetailsServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int rollNo = Integer.parseInt(request.getParameter("rollNo"));
        String name = request.getParameter("name");
        int age = Integer.parseInt(request.getParameter("age"));
        int mobileNo = Integer.parseInt(request.getParameter("mobileNo"));
        String countryCode = request.getParameter("countryCode");
        String gender=request.getParameter("gender");
        //String email=request.getParameter("email");
        String email=null;
        String[] areaofint=request.getParameterValues("areaOfInterest");
        String combinedInterests = null;
        if (areaofint != null) {
            combinedInterests = String.join(",", areaofint);
        }
        

        final String DB_URL = "jdbc:sqlserver://localhost\\SQLEXPRESS;Database=students;integratedSecurity=true;Trusted_Connection=True;encrypt=true;trustServerCertificate=true";
        final String JDBC_DRIVER = "com.microsoft.sqlserver.jdbc.SQLServerDriver";

        try {
           
            Class.forName(JDBC_DRIVER);
            Connection conn = DriverManager.getConnection(DB_URL);
            
            String firstQuery="SET IDENTITY_INSERT dbo.details ON";
            String query = String.format(
            	    "EXEC insertStudentDetails %d, '%s', %d, %d, '%s', '%s', '%s', '%s'",
            	    rollNo,
            	    name.replace("'", "''"),
            	    age,
            	    mobileNo,
            	    countryCode.replace("'", "''"),
            	    gender.replace("'", "''"),
            	    email == null ? "NULL" : email.replace("'", "''"),
            	    combinedInterests == null ? "NULL" : combinedInterests.replace("'", "''")
            	);

            System.out.println(query);          
            Statement stmt = conn.createStatement();
            stmt.execute(firstQuery);
            int rowsInserted = stmt.executeUpdate(query);

         
            stmt.close();
            conn.close();

            if (rowsInserted > 0) {
                request.setAttribute("successMessage", "Student details saved successfully!");
                request.getRequestDispatcher("studentform/success.jsp").forward(request, response);
            } else {
                request.setAttribute("errorMessage", "Failed to save Student details.");
                request.getRequestDispatcher("studentform/error.jsp").forward(request, response);
            }

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "An error occurred: " + e.getMessage());
            request.getRequestDispatcher("studentform/error.jsp").forward(request, response);
        }
    }
}